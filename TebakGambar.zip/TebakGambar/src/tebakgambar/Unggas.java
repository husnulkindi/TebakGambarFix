/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package tebakgambar;

/**
 *
 * @author Juli
 */
public class Unggas {
    
    private String nomor;
    private String gambarunggas;
    private String optiA;
    private String optiB;
    private String optiC;
    private String optiD;

    public Unggas(String nomor, String gambarunggas,
            String optiA, String optiB, String optiC, String optiD) {
        this.nomor = nomor;
        this.gambarunggas = gambarunggas;
        this.optiA = optiA;
        this.optiB = optiB;
        this.optiC = optiC;
        this.optiD = optiD;
    }

    public String getNomor() {
        return nomor;
    }

    public String getGambarunggas() {
        return gambarunggas;
    }

    public String getOptiA() {
        return optiA;
    }

    public String getOptiB() {
        return optiB;
    }

    public String getOptiC() {
        return optiC;
    }

    public String getOptiD() {
        return optiD;
    }

    
    
}
    

